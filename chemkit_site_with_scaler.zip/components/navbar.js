class CustomNavbar extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        .navbar-link {
          display: inline-flex;
          align-items: center;
          padding: 8px 16px;
          border-radius: 9999px;
          transition: all 0.3s ease;
          background: rgba(16, 185, 129, 0.1);
          border: 1px solid rgba(16, 185, 129, 0.2);
          position: relative;
          overflow: hidden;
        }
        
        .navbar-link::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(139, 92, 246, 0.2));
          transform: scaleX(0);
          transform-origin: left;
          transition: transform 0.3s ease;
          z-index: -1;
        }
        
        .navbar-link:hover {
          border-color: rgba(16, 185, 129, 0.5);
          box-shadow: 0 4px 15px rgba(16, 185, 129, 0.2);
        }
        
        .navbar-link:hover::before {
          transform: scaleX(1);
        }
        
        .navbar-link i {
          margin-right: 6px;
        }
        .cart-count {
          display: none;
          position: absolute;
          top: -5px;
          right: -5px;
          background-color: white;
          color: #10b981;
          border-radius: 50%;
          width: 20px;
          height: 20px;
          font-size: 12px;
          font-weight: bold;
          align-items: center;
          justify-content: center;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
@media (max-width: 768px) {
          .mobile-menu {
            display: none;
          }
          
          .mobile-menu.open {
            display: block;
          }
        }
      </style>
      <nav class="bg-gray-800 text-white shadow-lg border-b border-gray-700">
<div class="container mx-auto px-4">
          <div class="flex justify-between items-center py-4">
            <a href="/" class="flex items-center space-x-2 group">
              <div class="relative">
                <i data-feather="flask" class="w-6 h-6 text-primary-500 group-hover:text-primary-400 transition"></i>
                <div class="absolute -inset-2 bg-primary-500 rounded-full opacity-0 group-hover:opacity-10 transition duration-300"></div>
              </div>
              <span class="text-xl font-bold bg-gradient-to-r from-primary-500 to-secondary-500 bg-clip-text text-transparent">ChemKit<span class="text-white">Wonders</span></span>
            </a>
<div class="hidden md:flex items-center space-x-4">
              <a href="/" class="navbar-link">
                <i data-feather="home"></i>
                <span>Home</span>
              </a>
              <a href="/products.html" class="navbar-link">
                <i data-feather="flask"></i>
                <span>Products</span>
              </a>
              <a href="/about.html" class="navbar-link">
                <i data-feather="shield"></i>
                <span>About & Safety</span>
              </a>
<div class="relative">
            <a href="/cart.html" class="flex items-center relative group">
              <div class="flex items-center justify-center w-10 h-10 rounded-full bg-gray-700 group-hover:bg-gray-600 transition">
                <i data-feather="shopping-cart" class="w-5 h-5"></i>
                <span class="cart-count"></span>
              </div>
              <span class="ml-2 hidden md:inline">Cart</span>
            </a>
</div>
            </div>
            <button class="md:hidden focus:outline-none mobile-menu-button p-2 rounded-lg hover:bg-gray-700 transition">
              <i data-feather="menu" class="w-6 h-6"></i>
            </button>
</div>
        </div>
        
        <!-- Mobile menu -->
            <div class="mobile-menu md:hidden bg-gray-700">
              <div class="container mx-auto px-4 py-4 space-y-3">
                <a href="/" class="flex items-center py-2 px-4 hover:bg-gray-600 rounded-lg transition">
                  <i data-feather="home" class="w-5 h-5 mr-3"></i>
                  <span>Home</span>
                </a>
                <a href="/products.html" class="flex items-center py-2 px-4 hover:bg-gray-600 rounded-lg transition">
                  <i data-feather="flask" class="w-5 h-5 mr-3"></i>
                  <span>Products</span>
                </a>
                <a href="/about.html" class="flex items-center py-2 px-4 hover:bg-gray-600 rounded-lg transition">
                  <i data-feather="shield" class="w-5 h-5 mr-3"></i>
                  <span>About & Safety</span>
                </a>
            <a href="/cart.html" class="flex items-center py-2 px-4 hover:bg-gray-600 rounded-lg transition">
              <i data-feather="shopping-cart" class="w-5 h-5 mr-3"></i>
              <span>Cart</span>
              <span class="cart-count ml-2"></span>
            </a>
</div>
        </div>
      </nav>
    `;
    
    // Mobile menu toggle
    const menuButton = this.shadowRoot.querySelector('.mobile-menu-button');
    const mobileMenu = this.shadowRoot.querySelector('.mobile-menu');
    
    menuButton.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
      
      const icon = menuButton.querySelector('i');
      if (mobileMenu.classList.contains('open')) {
        feather.icons['x'].toSvg().then(svg => {
          icon.outerHTML = svg;
        });
      } else {
        feather.icons['menu'].toSvg().then(svg => {
          icon.outerHTML = svg;
        });
      }
    });
    
    // Initialize cart count
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const count = cart.reduce((total, item) => total + item.quantity, 0);
    const cartCountElements = this.shadowRoot.querySelectorAll('.cart-count');
    
    cartCountElements.forEach(el => {
      el.textContent = count;
      if (count > 0) {
        el.style.display = 'flex';
      }
    });
    
    // Initialize feather icons
    feather.replace();
  }
}

customElements.define('custom-navbar', CustomNavbar);