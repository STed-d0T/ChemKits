class CustomProductCard extends HTMLElement {
  static get observedAttributes() {
    return ['title', 'price', 'image', 'href'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.render();
  }

  attributeChangedCallback(name, oldValue, newValue) {
    this.render();
  }

  render() {
    const title = this.getAttribute('title') || '';
    const price = this.getAttribute('price') || '0';
    const image = this.getAttribute('image') || '';
    const href = this.getAttribute('href') || '#';
    
    this.shadowRoot.innerHTML = `
      <style>
        .product-card {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .product-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }
        
        .product-image-container {
          height: 200px;
          overflow: hidden;
        }
        
        .product-image {
          transition: transform 0.5s ease;
        }
        
        .product-card:hover .product-image {
          transform: scale(1.05);
        }
        
        .price {
          color: #10b981;
        }
      </style>
      <div class="product-card bg-gray-800 rounded-lg overflow-hidden shadow-md">
        <a href="${href}">
          <div class="product-image-container">
            <img src="${image}" alt="${title}" class="w-full h-full object-cover product-image">
          </div>
          <div class="p-6">
            <h3 class="text-xl font-bold mb-2 text-white">${title}</h3>
            <div class="flex justify-between items-center">
              <span class="price font-bold text-lg">$${price}</span>
              <button class="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded transition duration-300">
                View Details
              </button>
            </div>
          </div>
        </a>
      </div>
    `;
  }
}

customElements.define('custom-product-card', CustomProductCard);