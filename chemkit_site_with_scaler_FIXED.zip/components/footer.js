class CustomFooter extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        .footer-link:hover {
          color: #10b981;
        }
        
        .social-icon {
          transition: all 0.3s ease;
        }
        
        .social-icon:hover {
          transform: translateY(-3px);
          color: #10b981;
        }
      </style>
      <footer class="bg-gray-800 text-gray-300 py-12">
        <div class="container mx-auto px-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 class="text-xl font-bold text-white mb-4">ChemKit Wonders</h3>
              <p class="mb-4">Safe, convenient chemistry kits for adult beginners.</p>
              <div class="flex space-x-4">
                <a href="#" class="social-icon">
                  <i data-feather="twitter" class="w-5 h-5"></i>
                </a>
                <a href="#" class="social-icon">
                  <i data-feather="instagram" class="w-5 h-5"></i>
                </a>
                <a href="#" class="social-icon">
                  <i data-feather="facebook" class="w-5 h-5"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h4 class="text-lg font-semibold text-white mb-4">Shop</h4>
              <ul class="space-y-2">
                <li><a href="/products.html" class="footer-link">All Products</a></li>
                <li><a href="/product-basic.html" class="footer-link">Starter Kit</a></li>
                <li><a href="/product-crystal.html" class="footer-link">Crystal Growing</a></li>
                <li><a href="/product-ph.html" class="footer-link">pH Testing</a></li>
              </ul>
            </div>
            
            <div>
              <h4 class="text-lg font-semibold text-white mb-4">Help</h4>
              <ul class="space-y-2">
                <li><a href="/about.html" class="footer-link">About & Safety</a></li>
                <li><a href="#" class="footer-link">Shipping Info</a></li>
                <li><a href="#" class="footer-link">Returns & Refunds</a></li>
                <li><a href="#" class="footer-link">Contact Us</a></li>
              </ul>
            </div>
            
            <div>
              <h4 class="text-lg font-semibold text-white mb-4">Newsletter</h4>
              <p class="mb-4">Subscribe for updates and new product announcements.</p>
              <form class="flex">
                <input type="email" placeholder="Your email" class="bg-gray-700 text-white px-4 py-2 rounded-l focus:outline-none focus:ring-2 focus:ring-primary-500 w-full">
                <button type="submit" class="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-r">
                  <i data-feather="send" class="w-4 h-4"></i>
                </button>
              </form>
            </div>
          </div>
          
          <div class="border-t border-gray-700 mt-8 pt-8 text-center">
            <p>&copy; ${new Date().getFullYear()} ChemKit Wonders. All rights reserved.</p>
          </div>
        </div>
      </footer>
    `;
    
    feather.replace();
  }
}

customElements.define('custom-footer', CustomFooter);