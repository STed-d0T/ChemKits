document.addEventListener('DOMContentLoaded', function() {
    // Initialize Stripe
    const stripe = Stripe('pk_test_your_stripe_publishable_key_here');
    
    // Cart functionality
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    function updateCartCount() {
        const count = cart.reduce((total, item) => total + item.quantity, 0);
        const cartCountElements = document.querySelectorAll('.cart-count');
        cartCountElements.forEach(el => {
            el.textContent = count;
            el.style.display = count > 0 ? 'flex' : 'none';
        });
    }
    
    // Example of adding to cart (used in product pages)
    window.addToCart = function(productId, productName, price) {
        const existingItem = cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                id: productId,
                name: productName,
                price: price,
                quantity: 1
            });
        }
        
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount();
        
        // Show notification with new style
        const notification = document.createElement('div');
        notification.className = 'fixed bottom-4 right-4 bg-gradient-to-r from-green-500 to-primary-600 text-white px-6 py-3 rounded-lg shadow-xl z-50 flex items-center';
        notification.innerHTML = `
            <i data-feather="check-circle" class="w-5 h-5 mr-2"></i>
            <span>${productName} added to cart!</span>
        `;
        document.body.appendChild(notification);
        feather.replace();
        
        // Add animation
        notification.style.transform = 'translateY(20px)';
        notification.style.opacity = '0';
        setTimeout(() => {
            notification.style.transform = 'translateY(0)';
            notification.style.opacity = '1';
            notification.style.transition = 'all 0.3s ease';
        }, 10);
        
        setTimeout(() => {
            notification.style.transform = 'translateY(20px)';
            notification.style.opacity = '0';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    };
// Initialize cart count on page load
    updateCartCount();
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Mobile menu toggle (handled in navbar component)
});

// Checkout function
async function initiateCheckout() {
    try {
        const response = await fetch('/create-checkout-session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                items: cart,
            }),
        });

        const session = await response.json();
        
        const result = await stripe.redirectToCheckout({
            sessionId: session.id
        });

        if (result.error) {
            alert(result.error.message);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Product page specific functions
if (window.location.pathname.includes('product-')) {
    // Additional product page scripts
    function toggleTab(tabId) {
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.querySelectorAll('.tab-button').forEach(button => {
            button.classList.remove('border-primary-500', 'text-primary-500');
            button.classList.add('border-transparent', 'text-gray-400');
        });
        
        document.getElementById(tabId).classList.remove('hidden');
        document.querySelector(`[data-tab="${tabId}"]`).classList.remove('border-transparent', 'text-gray-400');
        document.querySelector(`[data-tab="${tabId}"]`).classList.add('border-primary-500', 'text-primary-500');
    }
    
    // Initialize first tab as active
    if (document.querySelector('.tab-content')) {
        document.querySelector('.tab-content').classList.remove('hidden');
        document.querySelector('.tab-button').classList.add('border-primary-500', 'text-primary-500');
    }
}